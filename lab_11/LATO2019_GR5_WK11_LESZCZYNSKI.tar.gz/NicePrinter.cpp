#include "NicePrinter.h"

int NicePrinter::s_counter =0;
int NicePrinter::s_max = 0;

