#include "LicznikPoziomow.h"

int LicznikPoziomow::s_counter = 0;